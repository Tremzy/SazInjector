   _____           _____       _           _             
  / ____|         |_   _|     (_)         | |            
 | (___   __ _ ____ | |  _ __  _  ___  ___| |_ ___  _ __ 
  \___ \ / _` |_  / | | | '_ \| |/ _ \/ __| __/ _ \| '__|
  ____) | (_| |/ / _| |_| | | | |  __/ (__| || (_) | |   
 |_____/ \__,_/___|_____|_| |_| |\___|\___|\__\___/|_|   
                             _/ |                        
                            |__/                         


WinRar Password : 123

Download link : https://link-hub.net/41967/SazInjector

If you have any problem, bug or recommendation, open a ticket on the discord server.


--How to use-------------------------------------------------

- Turn off any antivirus on your computer
- Extract all the files using WinRAR (Password : 123)
- Launch the .exe file (Sunset.exe)
- Select a type of injection (**Manual Map recommended)
- Choose a process
- Add a .dll file
- Set up settings
- Run VAC-Bypass-Loader (Optional)
- Press Inject button
- Enjoy !

-------------------------------------------------------------


[+] If you want to avoid VAC ban :

	- Run the injector and the .dll file from an external disk or USB
	- Run the VAC-Bypass-Loader
	- Select "Manual Map" Injection
	- Clear recent dlls (Settings)
	- Check "Close After Injection" (Settings)


Good to know :
**Some dlls aren't working with the Manual Map injection (For example : Osiris.dll).
If the game crash after the injection, try to use Load Library injection type.